# Allows pygame to run without a display
export DISPLAY=:0
python3 main.py
