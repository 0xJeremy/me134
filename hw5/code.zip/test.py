from robot import Robot

robot = Robot()

robot.updatePosition()
